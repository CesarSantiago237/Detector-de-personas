# 🧠 Detector de Personas - Proyecto en Flask + YOLOv4-Tiny

<p align="center">
  <img src="https://raw.githubusercontent.com/CesarSantiago237/Detector-de-personas/main/frontend/static/images/portada.png" alt="Vista del Proyecto" width="700">
</p>

Este proyecto permite la detección, seguimiento y conteo de personas en tiempo real usando **YOLOv4-Tiny** y **OpenCV**, todo controlado mediante una interfaz web desarrollada en **Flask**. Ideal para control de aforos en eventos, comercios o espacios públicos.

---

## 🚀 Tecnologías usadas

- Python 3
- Flask
- OpenCV
- YOLOv4-Tiny
- Matplotlib
- WeasyPrint
- SQLite3
- HTML5 + CSS3 + JS (Frontend)

---

## 🛠️ Instalación

Clona el repositorio:

```bash
git clone https://github.com/CesarSantiago237/Detector-de-personas.git
cd Detector-de-personas

Instala las dependencias:

pip install -r requirements.txt

## 🏃‍♂️ Cómo ejecutar el proyecto

Desde la raíz del proyecto:

python -m backend.app

Una vez iniciado, verás en consola algo como:

🌐 Local: http://127.0.0.1:5000

🌐 Externo: http://tu-ip:5000 (para acceso desde red local/internet)

Abre tu navegador en cualquiera de las dos IPs.

## 📊 Funcionalidades principales

- Iniciar/Detener detección de personas.

- Activar cámara automáticamente (integrada o externa).

- Mostrar número de personas en vivo y el total histórico.

- Consultar histórico por periodos de tiempo (15 min, 30 min, 1h, 3h, todo el tiempo).

- Visualizar gráficas dinámicas (zoom in, zoom out, reset).

- Generar reportes PDF automáticos.

- Acceso local y desde Internet.

## 📂 Estructura general

Detector-de-personas/
├── backend/
│   ├── app.py
│   ├── __init__.py
│   └── database.py
├── detector/
│   ├── __init__.py
│   ├── detector.py
│   └── models/
│       ├── yolov4-tiny.cfg
│       ├── yolov4-tiny.weights
│       └── coco.names
├── frontend/
│   ├── static/
│   │   ├── style.css
│   │   ├── script.js
│   │   └── images/
│   └── templates/
│       └── index.html
├── config.py
├── requirements.txt
└── README.md
