import os
import cv2
import numpy as np
from collections import OrderedDict

class PeopleTracker:
    def __init__(self, max_disappeared=10):
        self.next_id = 0
        self.objects = OrderedDict()
        self.disappeared = OrderedDict()
        self.max_disappeared = max_disappeared
        self.total_count = 0

    def register(self, centroid):
        self.objects[self.next_id] = centroid
        self.disappeared[self.next_id] = 0
        self.next_id += 1
        self.total_count += 1
        return self.next_id - 1

    def deregister(self, object_id):
        del self.objects[object_id]
        del self.disappeared[object_id]

    def update(self, rects):
        if len(rects) == 0:
            for obj_id in list(self.disappeared.keys()):
                self.disappeared[obj_id] += 1
                if self.disappeared[obj_id] > self.max_disappeared:
                    self.deregister(obj_id)
            return self.objects

        input_centroids = np.zeros((len(rects), 2), dtype="int")

        for (i, (x, y, w, h)) in enumerate(rects):
            cx = x + w // 2
            cy = y + h // 2
            input_centroids[i] = (cx, cy)

        if len(self.objects) == 0:
            for i in range(len(input_centroids)):
                self.register(input_centroids[i])
        else:
            object_ids = list(self.objects.keys())
            object_centroids = list(self.objects.values())

            D = np.linalg.norm(np.array(object_centroids)[:, np.newaxis] - input_centroids, axis=2)
            rows = D.min(axis=1).argsort()
            cols = D.argmin(axis=1)[rows]

            used_rows = set()
            used_cols = set()

            for (row, col) in zip(rows, cols):
                if row in used_rows or col in used_cols:
                    continue

                object_id = object_ids[row]
                self.objects[object_id] = input_centroids[col]
                self.disappeared[object_id] = 0

                used_rows.add(row)
                used_cols.add(col)

            unused_rows = set(range(D.shape[0])).difference(used_rows)
            unused_cols = set(range(D.shape[1])).difference(used_cols)

            for row in unused_rows:
                object_id = object_ids[row]
                self.disappeared[object_id] += 1
                if self.disappeared[object_id] > self.max_disappeared:
                    self.deregister(object_id)

            for col in unused_cols:
                self.register(input_centroids[col])

        return self.objects

class PeopleDetector:
    def __init__(self, model_dir=None):
        # Configuración de rutas
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.model_dir = model_dir or os.path.join(base_dir, 'detector', 'models')
        
        self.model_cfg = os.path.join(self.model_dir, 'yolov4-tiny.cfg')
        self.model_weights = os.path.join(self.model_dir, 'yolov4-tiny.weights')
        self.classes_file = os.path.join(self.model_dir, 'coco.names')

        # Verificar archivos
        self._check_model_files()
        
        # Cargar modelo
        self.net = cv2.dnn.readNetFromDarknet(self.model_cfg, self.model_weights)
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        
        # Parámetros
        self.conf_threshold = 0.5
        self.nms_threshold = 0.4
        self.tracker = PeopleTracker()
        
        # Capas de salida
        self.layer_names = self.net.getLayerNames()
        self.output_layers = [self.layer_names[i - 1] for i in self.net.getUnconnectedOutLayers()]

    def _check_model_files(self):
        required_files = {
            'Configuración YOLO': self.model_cfg,
            'Pesos del modelo': self.model_weights,
            'Nombres de clases': self.classes_file
        }
        
        missing_files = []
        for name, path in required_files.items():
            if not os.path.exists(path):
                missing_files.append(f"{name}: {path}")
        
        if missing_files:
            raise FileNotFoundError(
                f"Archivos del modelo no encontrados:\n" + "\n".join(missing_files) +
                "\n\nDescarga los archivos desde:\n"
                "- yolov4-tiny.cfg: https://github.com/AlexeyAB/darknet/releases/download/darknet_yolo_v4_pre/yolov4-tiny.cfg\n"
                "- yolov4-tiny.weights: https://github.com/AlexeyAB/darknet/releases/download/darknet_yolo_v4_pre/yolov4-tiny.weights\n"
                "- coco.names: https://github.com/pjreddie/darknet/blob/master/data/coco.names"
            )

    def detect_and_track(self, frame):
        height, width = frame.shape[:2]
        
        # Detección
        blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
        self.net.setInput(blob)
        outs = self.net.forward(self.output_layers)
        
        # Procesamiento
        boxes = []
        confidences = []
        
        for out in outs:
            for detection in out:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                
                if class_id == 0 and confidence > self.conf_threshold:  # Solo personas
                    box = detection[0:4] * np.array([width, height, width, height])
                    (center_x, center_y, box_width, box_height) = box.astype("int")
                    
                    x = int(center_x - (box_width / 2))
                    y = int(center_y - (box_height / 2))
                    
                    boxes.append([x, y, int(box_width), int(box_height)])
                    confidences.append(float(confidence))
        
        # Non-Maximum Suppression
        indices = cv2.dnn.NMSBoxes(boxes, confidences, self.conf_threshold, self.nms_threshold)
        
        # Obtener rectángulos finales
        final_boxes = []
        if len(indices) > 0:
            final_boxes = [boxes[i] for i in indices.flatten()]
        
        # Tracking
        tracked_objects = self.tracker.update([(x, y, w, h) for (x, y, w, h) in final_boxes])
        
        # Dibujar resultados
        for (x, y, w, h) in final_boxes:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        for object_id, centroid in tracked_objects.items():
            text = f"ID:{object_id}"
            cv2.putText(frame, text, (centroid[0] - 10, centroid[1] - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        
        # Mostrar contadores
        cv2.putText(frame, f"Actuales: {len(tracked_objects)}", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        cv2.putText(frame, f"Total: {self.tracker.total_count}", (10, 70),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        
        return len(tracked_objects), self.tracker.total_count, frame