import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_CFG = os.path.join(BASE_DIR, "detector/models/yolov3.cfg")
MODEL_WEIGHTS = os.path.join(BASE_DIR, "detector/models/yolov3.weights")