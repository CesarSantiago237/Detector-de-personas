from fpdf import FPDF
from datetime import datetime
import os
from flask import current_app
from weasyprint import HTML
from tempfile import NamedTemporaryFile

class PDFReportGenerator:
    @staticmethod
    def generate_report(output_path, data):
        pdf = FPDF()
        pdf.add_page()
        
        # Configuración inicial
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.set_font("Arial", size=12)
        
        # Logo de la empresa (si existe)
        logo_path = os.path.join(current_app.static_folder, 'logo.png')
        if os.path.exists(logo_path):
            pdf.image(logo_path, x=10, y=8, w=30)
        
        # Encabezado
        pdf.set_font("Arial", 'B', 16)
        pdf.cell(0, 10, "Reporte de Conteo de Personas", ln=1, align='C')
        pdf.set_font("Arial", size=12)
        
        # Información del evento
        pdf.cell(0, 10, f"Evento: {data['event_name']}", ln=1)
        pdf.cell(0, 10, f"Fecha: {data['report_date']}", ln=1)
        pdf.cell(0, 10, f"Encargado: {data['operator_name']}", ln=1)
        pdf.cell(0, 10, f"Total de personas detectadas: {data['total_count']}", ln=1)
        
        # Gráfica (usaremos una imagen temporal)
        chart_img_path = os.path.join(current_app.static_folder, 'temp_chart.png')
        data['chart'].savefig(chart_img_path, bbox_inches='tight')
        pdf.image(chart_img_path, x=10, y=60, w=190)
        
        # Pie de página
        pdf.set_y(-15)
        pdf.set_font('Arial', 'I', 8)
        pdf.cell(0, 10, f'Generado el: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}', 0, 0, 'C')
        
        pdf.output(output_path)
        os.remove(chart_img_path)  # Limpiar archivo temporal

    @staticmethod
    def generate_html_report(data):
        """ Versión alternativa usando HTML/WeasyPrint para mejor diseño """
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial; margin: 2cm; }}
                .header {{ text-align: center; margin-bottom: 20px; }}
                .logo {{ height: 50px; }}
                .info {{ margin-bottom: 30px; }}
                .chart {{ width: 100%; margin: 20px 0; }}
                .footer {{ text-align: center; font-style: italic; margin-top: 30px; }}
            </style>
        </head>
        <body>
            <div class="header">
                {'<img src="file:///{}" class="logo">'.format(os.path.join(current_app.static_folder, 'logo.png')) 
                if os.path.exists(os.path.join(current_app.static_folder, 'logo.png')) else ''}
                <h1>Reporte de Conteo de Personas</h1>
            </div>
            
            <div class="info">
                <p><strong>Evento:</strong> {data['event_name']}</p>
                <p><strong>Fecha:</strong> {data['report_date']}</p>
                <p><strong>Encargado:</strong> {data['operator_name']}</p>
                <p><strong>Total de personas:</strong> {data['total_count']}</p>
            </div>
            
            <div class="chart">
                <img src="file://{os.path.join(current_app.static_folder, 'temp_chart.png')}" style="width: 100%;">
            </div>
            
            <div class="footer">
                Generado el {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            </div>
        </body>
        </html>
        """
        
        # Guardar HTML temporal
        with NamedTemporaryFile(suffix='.html', delete=False) as f:
            f.write(html_content.encode('utf-8'))
            html_path = f.name
        
        # Guardar gráfico temporal
        chart_img_path = os.path.join(current_app.static_folder, 'temp_chart.png')
        data['chart'].savefig(chart_img_path, bbox_inches='tight')
        
        # Convertir a PDF
        pdf_path = os.path.join(current_app.static_folder, 'temp_report.pdf')
        HTML(html_path).write_pdf(pdf_path)
        
        # Limpiar archivos temporales
        os.remove(html_path)
        os.remove(chart_img_path)
        
        return pdf_path