import os
os.environ["OPENCV_VIDEOIO_MSMF_ENABLE_HW_TRANSFORMS"] = "0"  # Para Windows

from flask import Flask, render_template, Response, jsonify, request, send_from_directory, send_file
import cv2
import threading
import numpy as np
from detector.detector import PeopleDetector
from datetime import datetime, timedelta
import json
import matplotlib.pyplot as plt
from fpdf import FPDF
import io
from werkzeug.utils import secure_filename
import tempfile

# Configuración de rutas absolutas
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__,
            template_folder=os.path.join(base_dir, 'frontend', 'templates'),
            static_folder=os.path.join(base_dir, 'frontend', 'static'))

# Configuración para subir archivos
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
UPLOAD_FOLDER = os.path.join(tempfile.gettempdir(), 'contador_personas_logos')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_available_cameras(max_to_check=5):
    """Devuelve una lista de cámaras disponibles"""
    available_cameras = []
    for i in range(max_to_check):
        cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
        if cap.isOpened():
            available_cameras.append(i)
            cap.release()
    return available_cameras

class DetectionState:
    def __init__(self):
        self.active = False
        self.current_count = 0
        self.total_count = 0
        self.cap = None
        self.lock = threading.Lock()
        self.placeholder = self._create_placeholder()
        self.history = []
        self.selected_camera = 0  # Cámara predeterminada
        self.available_cameras = get_available_cameras()

    def _create_placeholder(self):
        placeholder = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.putText(placeholder, "Sistema de Deteccion", (50, 240), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(placeholder, "Presione 'Iniciar' para comenzar", (50, 280),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)
        return placeholder

    def update_camera_list(self):
        """Actualiza la lista de cámaras disponibles"""
        self.available_cameras = get_available_cameras()
        # Asegurarse de que la cámara seleccionada sigue siendo válida
        if self.selected_camera not in self.available_cameras and self.available_cameras:
            self.selected_camera = self.available_cameras[0]

# Inicializar detector con manejo de errores
try:
    model_dir = os.path.join(base_dir, 'detector', 'models')
    detector = PeopleDetector(model_dir=model_dir)
    print("✅ Modelo YOLOv4-tiny cargado correctamente")
except Exception as e:
    print(f"❌ Error al cargar el detector: {e}")
    exit(1)

state = DetectionState()

def generar_reporte_pdf(datos_detecciones, nombre_evento, nombre_encargado, logo_paths=None):
    """Genera un reporte PDF con los datos de detección."""
    # Obtener el total acumulado del sistema
    total_acumulado = state.total_count if datos_detecciones else 0
    
    fechas = [datetime.fromisoformat(entry['timestamp']) for entry in datos_detecciones]
    conteos = [entry['current_count'] for entry in datos_detecciones]
    
    # Crear grafico
    plt.figure(figsize=(10, 6))
    plt.plot(fechas, conteos, marker='o', linestyle='-')
    plt.title("Personas detectadas por tiempo")
    plt.xlabel("Tiempo")
    plt.ylabel("Número de personas")
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Guardar grafico en memoria
    img_data = io.BytesIO()
    plt.savefig(img_data, format='png', bbox_inches='tight')
    plt.close()
    img_data.seek(0)
    
    # Crear PDF
    pdf = FPDF()
    pdf.add_page()
    
    # Configuracion
    pdf.set_font("Arial", size=12)
    
    # Agregar logos (máximo 2)
    if logo_paths:
        # Primer logo (izquierda)
        if len(logo_paths) > 0:
            pdf.image(logo_paths[0], x=10, y=8, w=30)
        
        # Segundo logo (derecha)
        if len(logo_paths) > 1:
            img_width = 30
            x_position = 210 - 10 - img_width  # 210 es el ancho de página A4, 10 es el margen
            pdf.image(logo_paths[1], x=x_position, y=8, w=30)
    
    # Información del reporte
    pdf.set_xy(10, 40)
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(0, 10, f"Reporte de Detecciones - {nombre_evento}", ln=1)
    pdf.set_font("Arial", size=12)
    pdf.cell(0, 10, f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", ln=1)
    pdf.cell(0, 10, f"Encargado: {nombre_encargado}", ln=1)
    pdf.cell(0, 10, f"Total acumulado: {total_acumulado}", ln=1)
    
    # Agregar grafico
    temp_img_path = os.path.join(tempfile.gettempdir(), "temp_chart.png")
    with open(temp_img_path, 'wb') as f:
        f.write(img_data.getbuffer())
    
    pdf.image(temp_img_path, x=10, y=80, w=180)
    os.remove(temp_img_path)
    
    # Guardar PDF en memoria
    pdf_output = io.BytesIO()
    pdf.output(pdf_output)
    pdf_output.seek(0)
    
    return pdf_output

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.static_folder, filename)

def generate_frames():
    while True:
        with state.lock:
            if not state.active:
                _, buffer = cv2.imencode('.jpg', state.placeholder)
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
                continue

            if state.cap is None:
                state.cap = cv2.VideoCapture(state.selected_camera, cv2.CAP_DSHOW)
                if not state.cap.isOpened():
                    print(f"Error: No se pudo abrir la cámara {state.selected_camera}")
                    _, buffer = cv2.imencode('.jpg', state.placeholder)
                    yield (b'--frame\r\n'
                           b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
                    continue
                state.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                state.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

            ret, frame = state.cap.read()
            if not ret:
                print("Error: No se pudo leer el frame")
                continue

            current, total, processed_frame = detector.detect_and_track(frame)
            state.current_count = current
            state.total_count = total

            _, buffer = cv2.imencode('.jpg', processed_frame)
            frame_bytes = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        
        if state.active:
                timestamp = datetime.now().isoformat()
                state.history.append({
                    "timestamp": timestamp,
                    "current_count": state.current_count,
                    "total_count": state.total_count
                })
                # Mantener solo datos de las últimas 24 horas
                state.history = [h for h in state.history 
                               if datetime.fromisoformat(h["timestamp"]) > datetime.now() - timedelta(hours=24)]   
            
@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                   mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/control', methods=['POST'])
def control_detection():
    action = request.json.get('action')
    
    with state.lock:
        if action == 'start' and not state.active:
            state.active = True
            print("Detección INICIADA")
        elif action == 'stop' and state.active:
            state.active = False
            if state.cap:
                state.cap.release()
                state.cap = None
            print("Detección DETENIDA")
    
    return jsonify({
        "status": state.active,
        "current_count": state.current_count,
        "total_count": state.total_count
    })

@app.route('/api/cameras', methods=['GET', 'POST'])
def handle_cameras():
    if request.method == 'GET':
        # Devuelve la lista de cámaras disponibles
        with state.lock:
            state.update_camera_list()
            return jsonify({
                "available_cameras": state.available_cameras,
                "selected_camera": state.selected_camera
            })
    elif request.method == 'POST':
        # Cambia la cámara seleccionada
        camera_id = request.json.get('camera_id')
        try:
            camera_id = int(camera_id)
            with state.lock:
                if camera_id in state.available_cameras:
                    state.selected_camera = camera_id
                    # Si la detección está activa, reiniciar la captura
                    if state.active and state.cap:
                        state.cap.release()
                        state.cap = None
                    return jsonify({"success": True, "message": f"Cámara cambiada a {camera_id}"})
                else:
                    return jsonify({"success": False, "message": "Cámara no disponible"}), 400
        except ValueError:
            return jsonify({"success": False, "message": "ID de cámara inválido"}), 400

@app.route('/api/status')
def get_status():
    return jsonify({
        "active": state.active,
        "current_count": state.current_count,
        "total_count": state.total_count
    })

@app.route('/api/chart_data')
def get_chart_data():
    with state.lock:
        return jsonify([{
            "timestamp": entry["timestamp"],
            "current_count": entry["current_count"],
            "total_count": entry["total_count"]
        } for entry in state.history])

@app.route('/generar_reporte', methods=['POST'])
def generar_reporte():
    """Endpoint para generar y descargar el reporte PDF."""
    try:
        # Obtener datos del formulario
        nombre_evento = request.form.get('nombre_evento', 'Evento sin nombre')
        nombre_encargado = request.form.get('nombre_encargado', 'Encargado no especificado')
        
        # Procesar archivos subidos
        logo_paths = []
        if 'logos' in request.files:
            files = request.files.getlist('logos')
            for i, file in enumerate(files[:2]):  # Limitar a 2 logos
                if file and allowed_file(file.filename):
                    filename = secure_filename(f"logo_{i}_{file.filename}")
                    filepath = os.path.join(UPLOAD_FOLDER, filename)
                    file.save(filepath)
                    logo_paths.append(filepath)
        
        # Obtener datos históricos
        with state.lock:
            datos_detecciones = state.history.copy()
        
        if not datos_detecciones:
            # Limpiar logos temporales si no hay datos
            for logo in logo_paths:
                try:
                    os.remove(logo)
                except:
                    pass
            return jsonify({"error": "No hay datos de detección para generar el reporte"}), 400
        
        # Generar PDF con los logos
        pdf_file = generar_reporte_pdf(
            datos_detecciones=datos_detecciones,
            nombre_evento=nombre_evento,
            nombre_encargado=nombre_encargado,
            logo_paths=logo_paths
        )
        
        # Limpiar logos temporales
        for logo in logo_paths:
            try:
                os.remove(logo)
            except:
                pass
        
        # Enviar PDF como descarga
        return send_file(
            pdf_file,
            as_attachment=True,
            download_name=f"reporte_detecciones_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
            mimetype='application/pdf'
        )
    except Exception as e:
        print(f"Error al generar reporte: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    # Verificación de rutas
    print(f"\n🔍 Verificación de rutas:")
    print(f"Ruta de templates: {app.template_folder}")
    print(f"Ruta de archivos estáticos: {app.static_folder}")
    print(f"Ruta de modelos: {os.path.join(base_dir, 'detector', 'models')}")
    print(f"Archivos en models: {os.listdir(os.path.join(base_dir, 'detector', 'models'))}\n")
    
    app.run(host='0.0.0.0', port=5000, threaded=True, debug=True)