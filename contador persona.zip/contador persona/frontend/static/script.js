// Elementos UI
const startBtn = document.getElementById('start-btn');
const stopBtn = document.getElementById('stop-btn');
const statusText = document.getElementById('status-text');
const statusLed = document.getElementById('status-led');
const currentCountDisplay = document.getElementById('current-count');
const totalCountDisplay = document.getElementById('total-count');
const chartContainer = document.getElementById('chart-container');
const toggleReportBtn = document.getElementById('toggle-report-btn');
const reportSection = document.getElementById('report-section');
const reportForm = document.getElementById('reportForm');
const logoInput = document.getElementById('logos');
const cameraSelect = document.getElementById('camera-select');
const refreshCamerasBtn = document.getElementById('refresh-cameras-btn');
const statusMessage = document.getElementById('status-message');

// Variables del gráfico
let peopleChart = null;
let allChartData = [];
const currentTimeRange = {
    minutes: 15,
    label: "15 min"
};

// Función para mostrar notificaciones
function showNotification(message, type = 'success') {
    const container = document.getElementById('notification-container');
    const notification = document.createElement('div');
    notification.className = `notification animate__animated animate__fadeInDown ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${type === 'success' ? '✓' : '⚠'}</span>
            <span class="notification-message">${message}</span>
        </div>
    `;
    
    container.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('animate__fadeOutUp');
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

// Configurar gráfico con zoom
function initChart() {
    const ctx = document.getElementById('people-chart').getContext('2d');
    
    peopleChart = new Chart(ctx, {
        type: 'line',
        data: { datasets: [] },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                zoom: {
                    zoom: {
                        wheel: { enabled: true },
                        pinch: { enabled: true },
                        mode: 'x'
                    },
                    pan: {
                        enabled: true,
                        mode: 'x'
                    }
                },
                legend: {
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.parsed.y}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'minute',
                        displayFormats: {
                            minute: 'HH:mm'
                        }
                    },
                    title: {
                        display: true,
                        text: 'Tiempo'
                    }
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Número de Personas'
                    }
                }
            },
            parsing: {
                xAxisKey: 'time',
                yAxisKey: 'value'
            }
        }
    });
}

// Obtener y actualizar la lista de cámaras disponibles
async function updateCameraList() {
    try {
        cameraSelect.disabled = true;
        cameraSelect.innerHTML = '<option value="-1">Cargando cámaras...</option>';
        
        const response = await fetch('/api/cameras');
        const data = await response.json();
        
        cameraSelect.innerHTML = '';
        
        if (data.available_cameras && data.available_cameras.length > 0) {
            data.available_cameras.forEach(camId => {
                const option = document.createElement('option');
                option.value = camId;
                option.text = camId === 0 ? 'Cámara predeterminada' : `Cámara ${camId}`;
                option.selected = camId === data.selected_camera;
                cameraSelect.appendChild(option);
            });
            showNotification("Lista de cámaras actualizada");
        } else {
            const option = document.createElement('option');
            option.value = "-1";
            option.text = "No se encontraron cámaras";
            cameraSelect.appendChild(option);
            showNotification("No se encontraron cámaras disponibles", 'error');
        }
        
        cameraSelect.disabled = false;
    } catch (error) {
        console.error("Error al actualizar lista de cámaras:", error);
        cameraSelect.innerHTML = '<option value="-1">Error al cargar cámaras</option>';
        showNotification("Error al cargar cámaras", 'error');
    }
}

// Cambiar la cámara seleccionada
async function changeCamera(cameraId) {
    try {
        const response = await fetch('/api/cameras', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ camera_id: cameraId })
        });
        
        const result = await response.json();
        if (result.success) {
            showNotification(`Cámara ${cameraId === '0' ? 'predeterminada' : cameraId} seleccionada correctamente`);
        } else {
            showNotification(result.message, 'error');
            await updateCameraList();
        }
    } catch (error) {
        console.error("Error al cambiar cámara:", error);
        showNotification("Error al cambiar de cámara", 'error');
    }
}

// Filtrar datos por rango temporal
function filterDataByTimeRange(minutes) {
    if (minutes === 0) return allChartData;
    
    const now = luxon.DateTime.now();
    const cutoff = now.minus({ minutes });
    
    return allChartData.filter(point => {
        const pointTime = luxon.DateTime.fromISO(point.time);
        return pointTime >= cutoff;
    });
}

// Actualizar gráfico con datos filtrados
function updateChartWithTimeRange() {
    if (!peopleChart) return;
    
    const filteredData = filterDataByTimeRange(currentTimeRange.minutes);
    const labels = filteredData.map(point => point.time);
    
    peopleChart.data.labels = labels;
    peopleChart.data.datasets = [
        {
            label: 'Personas en cámara',
            data: filteredData.map(point => ({
                time: point.time,
                value: point.current
            })),
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.1)',
            borderWidth: 2,
            tension: 0.3,
            fill: true
        },
        {
            label: 'Total acumulado',
            data: filteredData.map(point => ({
                time: point.time,
                value: point.total
            })),
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.1)',
            borderWidth: 2,
            tension: 0.3,
            fill: true
        }
    ];
    
    peopleChart.update();
}

// Cargar datos del gráfico
async function loadChartData() {
    try {
        const response = await fetch('/api/chart_data');
        const data = await response.json();
        
        allChartData = data.map(item => ({
            time: item.timestamp,
            current: item.current_count,
            total: item.total_count
        }));
        
        if (!peopleChart) {
            initChart();
        }
        
        updateChartWithTimeRange();
    } catch (error) {
        console.error("Error cargando datos del gráfico:", error);
        showNotification("Error al cargar datos del gráfico", 'error');
    }
}

// Actualizar estado
async function updateStatus() {
    try {
        const res = await fetch('/api/status');
        const data = await res.json();
        
        if (data.active) {
            statusText.textContent = "Activo";
            statusText.className = "status-label active";
            statusLed.className = "status-led active";
            statusMessage.textContent = "Detección en progreso...";
            statusMessage.className = "status-message active";
            
            startBtn.disabled = true;
            stopBtn.disabled = false;
            chartContainer.style.display = 'none';
            toggleReportBtn.style.display = 'none';
            reportSection.style.display = 'none';
        } else {
            statusText.textContent = "Inactivo";
            statusText.className = "status-label";
            statusLed.className = "status-led";
            statusMessage.textContent = "Sistema listo para iniciar detección";
            statusMessage.className = "status-message";
            
            startBtn.disabled = false;
            stopBtn.disabled = true;
            chartContainer.style.display = 'block';
            toggleReportBtn.style.display = 'block';
            await loadChartData();
        }
        
        currentCountDisplay.textContent = data.current_count;
        totalCountDisplay.textContent = data.total_count;
        
    } catch (error) {
        console.error("Error al actualizar estado:", error);
        showNotification("Error al actualizar estado", 'error');
    }
}

// Generar reporte PDF
async function generarReporte(event) {
    event.preventDefault();
    
    const nombreEvento = document.getElementById('nombre_evento').value;
    const nombreEncargado = document.getElementById('nombre_encargado').value;
    const files = logoInput.files;
    
    if (files.length > 2) {
        showNotification("Por favor, sube un máximo de 2 logos", 'error');
        return;
    }
    
    for (let file of files) {
        if (file.size > 2 * 1024 * 1024) {
            showNotification(`El archivo ${file.name} excede el tamaño máximo de 2MB`, 'error');
            return;
        }
    }
    
    try {
        const formData = new FormData();
        formData.append('nombre_evento', nombreEvento);
        formData.append('nombre_encargado', nombreEncargado);
        
        for (let i = 0; i < Math.min(files.length, 2); i++) {
            formData.append('logos', files[i]);
        }
        
        const response = await fetch('/generar_reporte', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            showNotification("Reporte PDF generado correctamente");
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `reporte_detecciones_${new Date().toISOString().slice(0,10)}.pdf`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            reportSection.style.display = 'none';
            reportForm.reset();
        } else {
            const error = await response.json();
            showNotification(`Error: ${error.error || 'Error desconocido'}`, 'error');
        }
    } catch (error) {
        console.error("Error al generar reporte:", error);
        showNotification("Error al generar el reporte", 'error');
    }
}

// Mostrar/ocultar formulario de reporte
function toggleReportForm() {
    if (reportSection.style.display === 'none') {
        reportSection.style.display = 'block';
    } else {
        reportSection.style.display = 'none';
    }
}

// Event Listeners
startBtn.addEventListener('click', async () => {
    try {
        await fetch('/api/control', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'start' })
        });
        showNotification("Detección iniciada correctamente");
        updateStatus();
    } catch (error) {
        console.error("Error al iniciar:", error);
        showNotification("Error al iniciar la detección", 'error');
    }
});

stopBtn.addEventListener('click', async () => {
    try {
        await fetch('/api/control', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'stop' })
        });
        showNotification("Detección detenida correctamente");
        updateStatus();
    } catch (error) {
        console.error("Error al detener:", error);
        showNotification("Error al detener la detección", 'error');
    }
});

cameraSelect.addEventListener('change', async () => {
    if (cameraSelect.value !== "-1") {
        await changeCamera(cameraSelect.value);
    }
});

refreshCamerasBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    await updateCameraList();
});

document.querySelectorAll('.time-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.time-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        currentTimeRange.minutes = parseInt(this.dataset.minutes);
        currentTimeRange.label = this.textContent;
        
        updateChartWithTimeRange();
    });
});

document.getElementById('zoom-in-btn').addEventListener('click', () => {
    if (peopleChart) {
        peopleChart.zoom(1.1);
    }
});

document.getElementById('zoom-out-btn').addEventListener('click', () => {
    if (peopleChart) {
        peopleChart.zoom(0.9);
    }
});

document.getElementById('reset-zoom-btn').addEventListener('click', () => {
    if (peopleChart) {
        peopleChart.resetZoom();
        updateChartWithTimeRange();
    }
});

toggleReportBtn.addEventListener('click', toggleReportForm);
reportForm.addEventListener('submit', generarReporte);

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    initChart();
    updateStatus();
    updateCameraList();
    
    // Actualizar cada segundo
    setInterval(updateStatus, 1000);
});